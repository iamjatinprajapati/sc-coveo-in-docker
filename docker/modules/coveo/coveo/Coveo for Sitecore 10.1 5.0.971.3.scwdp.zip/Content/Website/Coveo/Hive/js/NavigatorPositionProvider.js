(window["webpackJsonpCoveoForSitecore"] = window["webpackJsonpCoveoForSitecore"] || []).push([["NavigatorPositionProvider"],{

/***/ "./src/ui/distance/NavigatorPositionProvider.ts":
/*!******************************************************!*\
  !*** ./src/ui/distance/NavigatorPositionProvider.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var coveo_search_ui_1 = __webpack_require__(/*! coveo-search-ui */ "coveo-search-ui");
var NavigatorPositionProvider = /** @class */ (function (_super) {
    __extends(NavigatorPositionProvider, _super);
    function NavigatorPositionProvider(element, options, bindings) {
        var _this = _super.call(this, element, NavigatorPositionProvider.ID, bindings) || this;
        _this.element = element;
        _this.options = options;
        _this.bindings = bindings;
        _this.options = coveo_search_ui_1.ComponentOptions.initComponentOptions(element, NavigatorPositionProvider, options);
        _this.bind.onRootElement(coveo_search_ui_1.DistanceEvents.onResolvingPosition, _this.onResolvingPosition);
        return _this;
    }
    NavigatorPositionProvider.prototype.onResolvingPosition = function (args) {
        var _this = this;
        args.providers.push({
            getPosition: function () { return _this.getPosition(); },
        });
    };
    NavigatorPositionProvider.prototype.getPosition = function () {
        return new Promise(function (resolve, reject) {
            navigator.geolocation.getCurrentPosition(function (position) {
                resolve({
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                });
            }, function (error) {
                reject(error);
            });
        });
    };
    NavigatorPositionProvider.ID = 'NavigatorPositionProvider';
    NavigatorPositionProvider.options = {};
    return NavigatorPositionProvider;
}(coveo_search_ui_1.Component));
exports.NavigatorPositionProvider = NavigatorPositionProvider;
coveo_search_ui_1.Initialization.registerAutoCreateComponent(NavigatorPositionProvider);


/***/ })

}]);
//# sourceMappingURL=NavigatorPositionProvider.js.map