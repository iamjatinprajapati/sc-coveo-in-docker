(window["webpackJsonpCoveoForSitecore"] = window["webpackJsonpCoveoForSitecore"] || []).push([["CoveoForSitecoreExternalContent"],{

/***/ "./src/ui/scopes/CoveoForSitecoreExternalContent.ts":
/*!**********************************************************!*\
  !*** ./src/ui/scopes/CoveoForSitecoreExternalContent.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var coveo_search_ui_1 = __webpack_require__(/*! coveo-search-ui */ "coveo-search-ui");
var TabUtils_1 = __webpack_require__(/*! ../../utils/TabUtils */ "./src/utils/TabUtils.ts");
var ExpressionEvents_1 = __webpack_require__(/*! ../../events/ExpressionEvents */ "./src/events/ExpressionEvents.ts");
var CoveoForSitecoreExternalContent = /** @class */ (function (_super) {
    __extends(CoveoForSitecoreExternalContent, _super);
    function CoveoForSitecoreExternalContent(element, options, bindings) {
        var _this = _super.call(this, element, CoveoForSitecoreExternalContent.ID, bindings) || this;
        _this.element = element;
        _this.options = options;
        _this.bindings = bindings;
        _this.options = coveo_search_ui_1.ComponentOptions.initComponentOptions(element, CoveoForSitecoreExternalContent, options);
        _this.bind.onRootElement(ExpressionEvents_1.SitecoreExpressionEvents.onBuildingSitecoreExternalContent, _this.onBuildingSitecoreExternalContent);
        return _this;
    }
    CoveoForSitecoreExternalContent.prototype.onBuildingSitecoreExternalContent = function (buildingExternalContentEventArgs) {
        var _a;
        if (this.shouldAddExternalContent()) {
            (_a = buildingExternalContentEventArgs.sources).push.apply(_a, this.options.scSources);
        }
    };
    CoveoForSitecoreExternalContent.prototype.shouldAddExternalContent = function () {
        return TabUtils_1.isTabCurrentlySelected(this.options.scScopeToTab, this.searchInterface);
    };
    CoveoForSitecoreExternalContent.ID = 'ForSitecoreExternalContent';
    CoveoForSitecoreExternalContent.options = {
        scSources: coveo_search_ui_1.ComponentOptions.buildListOption(),
        scScopeToTab: coveo_search_ui_1.ComponentOptions.buildStringOption(),
    };
    return CoveoForSitecoreExternalContent;
}(coveo_search_ui_1.Component));
exports.CoveoForSitecoreExternalContent = CoveoForSitecoreExternalContent;
coveo_search_ui_1.Initialization.registerAutoCreateComponent(CoveoForSitecoreExternalContent);


/***/ }),

/***/ "./src/utils/TabUtils.ts":
/*!*******************************!*\
  !*** ./src/utils/TabUtils.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var coveo_search_ui_1 = __webpack_require__(/*! coveo-search-ui */ "coveo-search-ui");
function isTabCurrentlySelected(selected, searchInterface) {
    return !(!!selected && selected !== searchInterface.queryStateModel.get(coveo_search_ui_1.QueryStateModel.attributesEnum.t));
}
exports.isTabCurrentlySelected = isTabCurrentlySelected;


/***/ })

}]);
//# sourceMappingURL=CoveoForSitecoreExternalContent.js.map