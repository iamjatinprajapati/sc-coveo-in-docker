(window["webpackJsonpCoveoForSitecore"] = window["webpackJsonpCoveoForSitecore"] || []).push([["StaticPositionProvider"],{

/***/ "./src/ui/distance/StaticPositionProvider.ts":
/*!***************************************************!*\
  !*** ./src/ui/distance/StaticPositionProvider.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var coveo_search_ui_1 = __webpack_require__(/*! coveo-search-ui */ "coveo-search-ui");
var StaticPositionProvider = /** @class */ (function (_super) {
    __extends(StaticPositionProvider, _super);
    function StaticPositionProvider(element, options, bindings) {
        var _this = _super.call(this, element, StaticPositionProvider.ID, bindings) || this;
        _this.element = element;
        _this.options = options;
        _this.bindings = bindings;
        _this.options = coveo_search_ui_1.ComponentOptions.initComponentOptions(element, StaticPositionProvider, options);
        _this.bind.onRootElement(coveo_search_ui_1.DistanceEvents.onResolvingPosition, _this.onResolvingPosition);
        return _this;
    }
    StaticPositionProvider.prototype.onResolvingPosition = function (args) {
        var _this = this;
        if (this.canGetPosition()) {
            args.providers.push({
                getPosition: function () { return _this.getPosition(); },
            });
        }
    };
    StaticPositionProvider.prototype.canGetPosition = function () {
        return !!this.options.latitude && !!this.options.longitude;
    };
    StaticPositionProvider.prototype.getPosition = function () {
        return Promise.resolve({
            longitude: this.options.longitude,
            latitude: this.options.latitude,
        });
    };
    StaticPositionProvider.ID = 'StaticPositionProvider';
    StaticPositionProvider.options = {
        latitude: coveo_search_ui_1.ComponentOptions.buildNumberOption({
            required: true,
            float: true,
        }),
        longitude: coveo_search_ui_1.ComponentOptions.buildNumberOption({
            required: true,
            float: true,
        }),
    };
    return StaticPositionProvider;
}(coveo_search_ui_1.Component));
exports.StaticPositionProvider = StaticPositionProvider;
coveo_search_ui_1.Initialization.registerAutoCreateComponent(StaticPositionProvider);


/***/ })

}]);
//# sourceMappingURL=StaticPositionProvider.js.map