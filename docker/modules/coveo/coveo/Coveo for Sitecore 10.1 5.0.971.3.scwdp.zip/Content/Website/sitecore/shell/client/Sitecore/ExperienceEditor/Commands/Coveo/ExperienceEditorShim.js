define(["sitecore"], function (Sitecore) {
    try {
        return require("/-/speak/v1/ExperienceEditor/ExperienceEditor.js");;
    } catch (exception) {
        return Sitecore.ExperienceEditor;
    }
});